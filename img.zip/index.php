<?php 

    require "home/inicio.php";